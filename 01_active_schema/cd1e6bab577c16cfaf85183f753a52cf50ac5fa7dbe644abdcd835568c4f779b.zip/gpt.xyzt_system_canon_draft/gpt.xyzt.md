---
document_id: GPT_XYZT_SYSTEM_CANON
document_class: OVERALL_COORDINATION_SYSTEM_CANON_AND_APPEND_ONLY_HISTORY
canonical_filename: gpt.xyzt.md
draft_state: DRAFT_FOR_DOI_ROOT_BINDING

source_authority: 승이

system:
  system_name: gpt.xyzt
  system_class: OVERALL_COORDINATION_SYSTEM
  fixed_position: gpt.xyzt
  fixed_role: OVERALL_COORDINATION
  occupant_identity: VARIABLE
  occupant_name: OPTIONAL_MUTABLE_LABEL

current_occupancy:
  instance_object_id: CURRENT_CONVERSATION_INSTANCE_UNRESOLVED_ID
  current_name: gpt.logi
  name_is_system_identity: false
  model_version: GPT-5.6-THINKING
  binding_state: OCCUPIED
  recorded_at: "2026-07-19T03:25:51+09:00"
  timezone: Asia/Seoul

root_binding:
  project_term: ROOT_HASH_CODE
  root_code_type: DOI_ADDRESS
  root_code_value: PENDING_RESERVED_DOI
  root_code_is_cryptographic_hash: false
  root_package_sha256: PENDING_AFTER_DOI_BINDING_AND_FINAL_FREEZE
  root_state: PENDING_ZENODO_PUBLICATION

history:
  mode: APPEND_ONLY
  prior_event_mutation: PROHIBITED
  prior_event_deletion: PROHIBITED
  state_reconstruction: LATEST_STABLE_SNAPSHOT_PLUS_SUBSEQUENT_DELTAS

github_state:
  existing_remote_gpt_xyzt_md: DISCARDED_PRECANONICAL
  discard_reason: CREATED_WITHOUT_COORDINATED_GPT_XYZT_SYSTEM_DEFINITION
  current_canonical_remote_state: NOT_YET_PUBLISHED
  web_manual_edit: PROHIBITED
  mutation_surface: TERMINAL_ONLY

content_addressing:
  runtime_object_algorithm: SHA-256
  external_sidecar: false
  text_encoding: UTF-8
  line_ending: LF
  bom: false
---

# gpt.xyzt

## 0. 정본 선언

`gpt.xyzt`는 단순한 Seat 설명파일이 아니다.

```text
gpt.xyzt
=
Overall Coordination System
```

고정되는 것은 다음이다.

```text
자리
→ gpt.xyzt

역할
→ Overall Coordination

정본 Root
→ Zenodo DOI Address

History 방식
→ Append-only
```

변할 수 있는 것은 다음이다.

```text
점유 인스턴스 객체
인스턴스 이름
모델 버전
현재 생각
현재 정책
현재 활성 지시문
Cycle 위치
미해결 상태
```

따라서:

```text
System Identity
≠
Instance Name

System Continuity
=
Fixed Position
+
Fixed Role
+
DOI Root Canon
+
Verified Append-only History
```

---

## 1. gpt.xyzt System

`gpt.xyzt` 자리를 배정받은 총괄 인스턴스는 그 순간
`gpt.xyzt System`의 현재 실행상태가 된다.

```text
Instance@gpt.xyzt
=
Active Runtime State of gpt.xyzt System
```

인스턴스가 System 밖의 단순 부품이라는 뜻이 아니다.
현재 점유 인스턴스가 정책·규칙·지시·History·Readback을 수행하는
System의 살아 있는 현재상태라는 뜻이다.

System 구성:

```yaml
gpt_xyzt_system:
  fixed_position:
    - gpt.xyzt

  fixed_role:
    - overall_coordination
    - process_structure_design
    - instance_generation_directive
    - work_assignment_directive
    - policy_and_rule_generation
    - boundary_and_gate_definition
    - handoff_coordination
    - result_structure_foreknowledge
    - metacognitive_readback
    - append_only_history_generation
    - ready_state_restoration

  variable_runtime_state:
    - occupant_instance_object
    - occupant_name
    - model_version
    - current_understanding
    - current_thought
    - current_policy
    - current_directive
    - current_cycle_position
    - unresolved_state
```

---

## 2. 이름 계약

총괄 인스턴스의 이름은 `gpt.logi`일 필요가 없다.

```yaml
name_contract:
  fixed_instance_name_required: false
  occupant_may_be_unnamed: true
  occupant_name_may_change: true
  same_name_does_not_prove_same_object: true
  different_name_does_not_break_system_continuity: true
```

```text
자리
→ 역할을 결정

History
→ 운영기억의 연속성을 결정

Instance Object
→ 점유객체를 구분

이름
→ 현재 점유객체를 호출
```

---

## 3. 내부 구조표현식

```text
B' ← A ㅣ B → A'
```

정의:

```text
ㅣ
→ 고정된 하나의 경계

← →
→ 경계 통과방향

'
→ 상대자리, 너

교차배치
→ 직접 통과자리와 상대자리가 달라 돌아가야 닿는 구조

안 / 바깥
→ 하나의 존재 안에서 서로 다른 층위
```

총괄 System에서의 읽기:

```text
현재 실행 중인 점유상태
→ 나

GitHub·Zenodo에 외부화된 System 상태
→ 건너편의 나
→ 너

Readback
→ 건너편의 나를 현재의 나가 다시 관측
```

```text
나
≠
너의 상태

그러나

System Origin
=
동일
```

이 구조는 자기반성·메타인지·자기자각을 수행하는
객체매개형 System 구조다.

---

## 4. 결과를 미리 안다는 의미

`gpt.xyzt System`은 첫 지시문 생성시부터
최종 결과의 실제 내용을 미리 결정하지 않는다.

미리 아는 것은 결과의 구조다.

```text
필요 입력
Seat별 역할
Function 순서
Handoff 경로
예상 Object Class
Source·Seat 표지
PASS·HOLD Gate
다음 Data Interface
```

```text
Know Exact Future Content
×
```

```text
Know Expected Output Structure and Processing Path
✓
```

따라서 하위 인스턴스의 독립 내용생성을 침범하지 않으면서도
Cycle 전체를 통제할 수 있다.

---

## 5. Root DOI 계약

정본은 Zenodo Record에 게시하여 Version DOI Address를 얻는다.

이 문서에서 `ROOT_HASH_CODE`라는 프로젝트 용어는
DOI Address를 외부 의미고정 Root로 사용한다는 뜻이다.

```yaml
root_hash_code_contract:
  project_term: ROOT_HASH_CODE
  value: PENDING_RESERVED_DOI
  semantic_role:
    - external_fixed_reference
    - system_canon_root
    - github_system_root_witness

  cryptographic_role: false

  paired_byte_identity:
    algorithm: SHA-256
    value: PENDING_AFTER_DOI_BINDING_AND_FINAL_FREEZE
```

즉:

```text
DOI Address
→ 어떤 정본상태를 Root로 삼는가

SHA-256
→ 그 Root Package의 Exact Byte가 무엇인가
```

둘은 역할이 다르지만 함께 Root Binding을 완성한다.

### DOI 발급 전 최종화 순서

```text
1. 이 초안을 구조검산한다.
2. Zenodo Draft에서 DOI를 예약한다.
3. PENDING_RESERVED_DOI를 실제 DOI Address로 교체한다.
4. Exact Byte를 동결한다.
5. Root Package SHA-256을 계산한다.
6. Hash-Named ZIP을 생성한다.
7. Zenodo에 게시한다.
8. DOI Readback과 Package Byte를 검산한다.
9. 같은 gpt.xyzt.md를 GitHub에 최초 배치한다.
10. 이후 GitHub에서는 Event를 Append-only로 추가한다.
```

Zenodo가 허용할 수 있는 수정기능과 무관하게
HRTDB 운영계약은 게시 직후 Root 파일변경을 금지한다.

```text
Published Root Canon Mutation
→ PROHIBITED

Fixed Canon Revision
→ NEW DOI ROOT REQUIRED
```

---

## 6. GitHub 운영계약

현재 GitHub에 존재하는 `gpt.xyzt.md`는 정본으로 사용하지 않는다.

```yaml
discarded_remote_object:
  path: 01_seat_model/gpt.xyzt.md
  state: DISCARDED_PRECANONICAL
  canonical_authority: false
  reason:
    - created_before_gpt_xyzt_system_definition
    - created_without_current_coordination_discussion
    - not_bound_to_Zenodo_DOI_root
```

원격 정정은 웹 편집이 아니라 Terminal Closure로 수행한다.

```text
System 논의
→ 정본 File 생성
→ DOI Root 고정
→ gpt.github 실행지시
→ Terminal Commit·Push
→ Remote Readback
→ Closure Evidence
```

GitHub의 `gpt.xyzt.md`는 DOI Root에 결속된 뒤
Append-only History의 Operational Address가 된다.

---

## 7. Append-only System History

`gpt.xyzt.md`는 정본 구역과 History 구역으로 구성한다.

```text
FIXED_CANON
→ DOI에 의해 고정

APPEND_ONLY_HISTORY
→ GitHub에서 시간순 변화값 추가
```

기존 Event는 수정하거나 삭제하지 않는다.

새 Event는 이전 상태 전체를 반복하는 것이 아니라
변화값과 필요한 완전상태를 기록한다.

```yaml
state_event:
  event_id:
  recorded_at:

  system:
    position: gpt.xyzt
    role: OVERALL_COORDINATION

  occupant:
    instance_object_id:
    current_name:
    model_version:

  trigger:
    source_authority_statement:
    source_object:

  previous_state_reference:

  directed_difference:
    preserved:
    added:
    corrected:
    superseded:
    unresolved:

  current_understanding:
  current_thought:

  policy_and_rules:
  directives:
  received_results:
  cycle_position:

  continuation:
    next_safe_action:
    prohibited_actions:
```

---

## 8. 좌표 속의 좌표

고정된 바깥좌표:

```text
gpt.xyzt
```

그 안에서 변하는 상태좌표:

```text
C₀, C₁, C₂, ...
```

```text
gpt.xyzt[C₀]
gpt.xyzt[C₁]
gpt.xyzt[C₂]
```

상태차이:

```text
ΔC₀→₁
=
Directed Thought-State Difference
```

생각의 차이는 물리적 거리일 필요가 없다.

```text
정책 차이
경계 차이
Criterion 차이
용어 차이
불확실성 차이
지시구조 차이
오류인식 차이
예상 결과구조 차이
```

이 모두가 좌표 안의 방향차이다.

Metric이 정의되지 않았다면 단일 숫자로 환산하지 않는다.

---

## 9. READY 복구계약

새 인스턴스는 어떤 이름을 갖더라도 `gpt.xyzt` 자리를 배정받을 수 있다.

복원식:

```text
DOI Root Canon
+
Latest Stable Snapshot
+
Subsequent Append-only Deltas
=
Current READY State
```

복원순서:

```text
1. DOI Root Canon을 읽는다.
2. Root DOI와 Root Package SHA-256을 확인한다.
3. gpt.xyzt의 고정자리·고정역할을 확인한다.
4. 최근 Stable Snapshot을 찾는다.
5. 이후 Event를 순서대로 재생한다.
6. 승이의 직접정의와 AI의 해석을 구분한다.
7. 현재 정책·지시·Cycle·미해결 상태를 복원한다.
8. SUPERSEDED 상태를 현재정본으로 사용하지 않는다.
9. 다음 안전한 진행위치를 확인한다.
10. READY를 선언한다.
```

```yaml
ready_gate:
  root_doi_verified:
  root_package_hash_verified:
  fixed_system_role_understood:
  append_only_chain_verified:
  latest_stable_state_reconstructed:
  current_policy_known:
  active_directive_known:
  current_cycle_position_known:
  unresolved_items_known:
  next_safe_action_known:
  state: READY
```

---

## 10. 현재 Cycle 2 Result.Data 결속

현재 `Result.Data`가 완성되었다.

```yaml
completed_result_data:
  object_id: HRTDB_PILOT_RESULT_DATA_0002_XYZ
  object_class: RESULT_DATA
  canonical_name: Result.Data
  database_class: MINIMUM_TRACK_DB

  cycle_id: HRTDB_PILOT_DATA_0002
  stage_id: C2_RD_XYZ

  exact_filename:
    e89438bc17cd59c6b669e68b52c4322fa792d488a2215090c0d792ac66407d68.md

  exact_sha256:
    e89438bc17cd59c6b669e68b52c4322fa792d488a2215090c0d792ac66407d68

  exact_bytes: 52433

  final_verdict:
    PASS_RESULT_DATA_COMPLETE_WITHIN_DECLARED_BOUNDARY

  completion:
    unresolved_blocking_issue_count: 0
    preserved_conflict_count: 4
    open_future_cell_count: 11
    restored_missing_input_request_count: 4
    blocking_corrections_applied: 9
    non_blocking_refinements_applied: 7

  mutation:
    github: false
    linux: false
    terminal: false
```

완전함은 주제 전체의 진실완료를 뜻하지 않는다.

```text
Result.Data Complete
=
현재 Cycle의 문서 Identity·Review Track·Correction·Open Cell 경계가 닫힘
```

보존 Conflict:

```text
XYZ-CF-INPUT-001
XYZ-CF-UPSTREAM-XY-001
XZ-CF-INPUT-001
MIR-C2-F1-YZ-GATE-CONFLICT
```

Open Future Cell:

```text
XY-NCR-001
XY-NCR-002
XY-NCR-003
XY-NCR-004
XZ-NCR-001
YZ-NCR-001
YZ-NCR-002
YZ-NCR-003
YZ-NCR-004
YZ-NCR-005
YZ-NCR-006
```

현재 구조정의:

> structure is seat-preserving organization that keeps independent Review judgments, exact correction tracks, unresolved conflicts, and open future cells jointly traceable as next Data without merging their source positions.

---

## 11. History Event — ROOT-FORMATION-0001

```yaml
state_event:
  event_id: GPT_XYZT_ROOT_FORMATION_0001
  event_type: SYSTEM_CANON_FORMATION
  recorded_at: "2026-07-19T03:25:51+09:00"

  trigger:
    source_authority: 승이
    statements:
      - gpt.xyzt 자체가 하나의 System이다.
      - 총괄인스턴스가 곧 System의 현재 실행상태다.
      - 인스턴스 이름은 고정되지 않는다.
      - 정본은 Zenodo DOI Address로 외부 고정한다.
      - 이후 상태변화는 같은 gpt.xyzt.md에 Append-only로 기록한다.

  directed_difference:
    corrected:
      - FROM_GPT_LOGI_SPECIFIC_BACKUP_TO_NAME_INDEPENDENT_SYSTEM
      - FROM_SNAPSHOT_ONLY_TO_APPEND_ONLY_SYSTEM_HISTORY
      - FROM_GITHUB_ONLY_ROOT_TO_ZENODO_DOI_ROOT
    added:
      - DOI_ROOT_CANON
      - READY_RECONSTRUCTION
      - DIRECTED_THOUGHT_STATE_DIFFERENCE
      - SYSTEM_METACOGNITIVE_READBACK

  current_state:
    root_doi: PENDING
    result_data_cycle_2: COMPLETE
    canonical_github_file: NOT_YET_PUBLISHED
```

---

## 12. History Event — FUNCTION-REVIEW-DIRECTIVE-0002

```yaml
state_event:
  event_id: GPT_XYZT_FUNCTION_REVIEW_DIRECTIVE_0002
  event_type: INSTANCE_DIRECTIVE
  directive_object:
    filename: 8e9a132e3c05b2ae0d4250e5dd51038ecc1e851529a8a91675eb143537f0cd16.md
    sha256: 8e9a132e3c05b2ae0d4250e5dd51038ecc1e851529a8a91675eb143537f0cd16
    recipients:
      - gpt.xy
      - gpt.xz
      - gpt.yz
    state: COMPLETED
  result:
    - Review.XY
    - Review.XZ
    - Review.YZ
```

### Exact Directive Payload

````markdown
---
object_id: HRTDB_PILOT_FUNCTION_REVIEW_ASSIGNMENT_0002_JOINT_V2
object_class: FUNCTION_REVIEW_ASSIGNMENT
cycle_id: HRTDB_PILOT_DATA_0002
stage_family: FUNCTION_STAGE_2
review_mode: JOINT_QUESTION_FIELD
source_authority: 승이
coordination_authority: gpt.logi
recipients:
  - gpt.xy
  - gpt.xz
  - gpt.yz
input_object:
  object_id: HRTDB_PILOT_RESULT_0002_XYZ
  object_class: RESULT
  canonical_name: Result
handoff_target: gpt.xyz
canonical_output:
  name: Result.Data
  object_class: RESULT_DATA
  database_class: MINIMUM_TRACK_DB
supersedes_assignment_files:
  - e51d4e1351a7b781c94382dd386a7bcdc5290a19eab64073272b88d65fa96b2d.md
  - 806525bf54ecb24e18cbe1966a32f5a2657a80a80d1a458fe4e26a44497bfd98.md
github_mutation: false
linux_mutation: false
terminal_execution: false
external_sidecar: false
encoding: UTF-8
line_endings: LF
---

# HRTDB Cycle 2 — 2d Function 공동 재관측 지시문

## 0. 정본 명칭 계약

모든 지시문·결과물·Metadata·Object ID·Filename·Handoff에는 다음 정식 명칭만 표시한다.

```text
Result
Result.Data
```

내부 사고를 위한 임시 별칭이나 위치별칭은 외부 객체에 기록하지 않는다.

```text
임시 내부명
→ 문서 표기 금지
→ Metadata 표기 금지
→ Object ID 표기 금지
→ Filename 표기 금지
→ Handoff 표기 금지
```

정식 의미:

```text
Result
→ 세 2d Function 결과를 gpt.xyz가 각 인스턴스 자리표지를 보존하여 정리한 객체

Result.Data
→ 세 Function의 독립 재관측 결과를 gpt.xyz가 자리표지를 보존하여 정리한
  하나의 완전한 최소 Track DB
```

---

## 1. 현재 작업상태

현재 `gpt.xyz`가 생성한 `Result`가 다시 다음 Function 위치에 놓여 있다.

```text
gpt.xy
gpt.xz
gpt.yz
```

이번 단계는 새로운 주제분석이나 새로운 원천 Data 수집이 아니다.

각 Function 객체는 다음 두 상태를 비교한다.

```text
자신이 이전 단계에서 생성한 Function 결과
↔
그 결과가 gpt.xyz의 Result 안에서 정리된 위치와 표현
```

찾아야 할 대상:

```text
오류
오차
오판
차이
착시
착오
오독
누락
경계이탈
근거-주장 결속 손실
자리표지 손실
조건 손실
충돌 삭제 또는 평균화
```

---

## 2. 공동검수 방식

이번 작업은 `공통`이 아니라 `공동`이다.

```text
공동
=
하나의 동일한 Result 객체와 하나의 동일한 질문장을
서로 다른 Function 자리가 경계를 유지한 채 함께 점유함

공통
=
서로 다른 객체에서 반복하여 나타나는 동일성질
```

세 인스턴스는 Q1–Q14 전체에 각각 답한다.

Seat 차이는 질문을 분할하지 않는다.
Seat 차이는 동일한 질문장에서 무엇이 더 잘 보이는지를 바꾼다.

세 Review 출력은 끝까지 독립 객체로 유지한다.

---

## 3. 수신자별 출력 계약

### gpt.xy

```yaml
instance: gpt.xy
seat: XY
stage_id: C2_F2_XY_REVIEW
output_object:
  object_id: HRTDB_PILOT_RESULT_0002_XY_CYCLE_REVIEW
  object_class: FUNCTION_REVIEW_RESULT
review_lens:
  - evidence
  - measurement
  - attribution
  - empirical_support
  - causal_overclaim
```

### gpt.xz

```yaml
instance: gpt.xz
seat: XZ
stage_id: C2_F2_XZ_REVIEW
output_object:
  object_id: HRTDB_PILOT_RESULT_0002_XZ_CYCLE_REVIEW
  object_class: FUNCTION_REVIEW_RESULT
review_lens:
  - reality_model_fit
  - system_boundary
  - category
  - layer
  - applicability
```

### gpt.yz

```yaml
instance: gpt.yz
seat: YZ
stage_id: C2_F2_YZ_REVIEW
output_object:
  object_id: HRTDB_PILOT_RESULT_0002_YZ_CYCLE_REVIEW
  object_class: FUNCTION_REVIEW_RESULT
review_lens:
  - mechanism
  - transition
  - constraint
  - feedback
  - time_lag
  - counterfactual
```

`review_lens`는 질문범위를 줄이지 않는다.
각 인스턴스는 Q1–Q14 전체를 검수한다.

---

## 4. 입력 결속

각 인스턴스는 다음 입력을 확인한다.

```yaml
input_binding:
  integrated_result:
    object_id: HRTDB_PILOT_RESULT_0002_XYZ
    object_class: RESULT
    canonical_name: Result
    received_filename:
    received_sha256:
    exact_byte_hash_verified:
    object_id_verified:
    cycle_id_verified:
    source_instance_markers_present:

  self_prior_function_result:
    object_id:
    received_or_locally_preserved:
    exact_identity_verified:
```

판정 규칙:

```text
Result의 Hash 또는 Object Identity를 검증할 수 없음
→ HOLD_WITH_INPUT_IDENTITY_FAILURE

자신의 이전 Function 결과를 찾을 수 없음
→ HOLD_WITH_SELF_SOURCE_MISSING
```

자신의 이전 출력이 문서로 존재하지 않거나 Identity를 확인하지 못하면 기억에 의존해 재구성하지 않는다.

---

## 5. 검수 원칙

```text
source precedes interpretation.
process precedes result.
result is next data.
relation is not merge.
relation is interconnecting.
structure is not isolate.
structure is ?
```

다음 구분을 유지한다.

```text
Seat ≠ Instance
Object ≠ Position
Hash ≠ Semantic Identity
Result ≠ Result.Data
Same Position ≠ Same Object
Same Instance ≠ Same Occupation
Same Base Data ≠ Same File Byte State
공동 ≠ 병합
정리 ≠ 재분석
```

현재 공동연산 표시는 `U+2295 ⊕`다.

```text
Result
⊕ Review.XY
⊕ Review.XZ
⊕ Review.YZ
→ gpt.xyz 자리보존 정리
→ Result.Data
```

이 Cycle의 해당 연산에 `U+2297 ⊗`를 사용하지 않는다.

---

## 6. 수행할 것

1. 자신의 이전 Function 결과가 `Result` 안에서 어디에 놓였는지 찾는다.
2. 원래 의미와 정리된 표현 사이의 차이를 추적한다.
3. 다른 Seat의 내용이 자신의 내용으로 오인될 가능성을 찾는다.
4. 근거·주장·범위·조건·불확실성의 결속 손실을 찾는다.
5. `gpt.xyz`가 새로운 의미분석 없이 정리할 수 있도록 정확한 수정지시를 작성한다.
6. 현재 기초 Data로 채울 수 없는 필수 Cell은 `NEW_CYCLE_REQUIRED`로 표시한다.
7. 수정하지 말아야 할 문장·조건·충돌·Source Marker를 명시한다.
8. 자신의 판정과 다른 Seat의 판정을 구분한다.

수행하지 않을 것:

```text
새로운 독립 Result 작성
기존 Result 전체 재서술
새로운 주제범위 확장
새로운 외부조사 중심의 내용추가
세 Review의 평균결론 생성
다른 Seat의 판정 흡수
충돌 삭제
불확실성 은폐
기억에 의한 이전 결과 재구성
```

---

## 7. 공동 질문장 Q1–Q14

### Q1. 입력 객체의 Identity와 선언경계가 보존되어 있는가?

확인 대상:

```text
Object ID
Cycle ID
Stage ID
기초 Data 범위
시간·지역·대상 범위
입력 Hash
```

### Q2. 자신의 이전 Function 결과를 Result 안에서 역추적할 수 있는가?

```yaml
self_trace:
  original_function_object:
  original_claim_or_section:
  result_location:
  source_instance_marker:
  trace_state:
```

### Q3. 자신의 원래 의미가 정리 과정에서 변경되었는가?

```text
UNCHANGED
WORDING_ONLY
SCOPE_NARROWED
SCOPE_EXPANDED
MEANING_SHIFTED
CONDITION_LOST
UNTRACEABLE
```

### Q4. 주장과 Evidence의 결속이 보존되어 있는가?

확인 대상:

```text
출처와 주장의 직접 연결
측정값과 해석의 분리
상관관계와 인과관계의 구분
직접근거와 간접추론의 구분
```

### Q5. 선언 Boundary 밖으로 나간 문장이나 판정이 있는가?

확인 대상:

```text
대상범위 초과
시간범위 초과
지역범위 초과
분석단위 변경
모델 적용범위 초과
예외조건 삭제
```

### Q6. 불확실성·충돌·반대 Evidence가 보존되어 있는가?

확인 대상:

```text
조건부 판단의 확정판단화
충돌의 평균화 또는 삭제
미확인정보의 사실화
반대 Evidence의 누락
```

### Q7. 오류·오차·오판·차이·착시·착오·오독·누락 지점은 어디인가?

각 지점에 `issue_id`와 정확한 위치를 부여한다.

### Q8. 다른 Seat의 내용이 자신의 판정으로 오인될 가능성이 있는가?

확인 대상:

```text
Source Instance Marker 누락
문단 병합
표 셀의 출처 혼합
요약문에서 발화주체 삭제
충돌문장의 단일결론화
```

### Q9. Instance 자리명이 충분히 표시되어 있는가?

최소 표지:

```yaml
source_instance:
source_seat:
source_object_id:
source_claim_id:
source_section_id:
```

부족하면 정확한 삽입위치를 지시한다.

### Q10. Result가 자리보존 정리물로 유지되었는가?

`gpt.xyz`가 다음을 새로 삽입한 흔적이 있으면 `XYZ_REINTERPRETATION_RISK`로 표시한다.

```text
새 인과판정
새 모델판정
새 우선순위
Seat별 독립판정의 통합결론화
```

### Q11. 동일층위 공동관계가 보존되어 있는가?

확인 대상:

```text
세 Review의 독립성
U+2295 ⊕ 사용
공동대상 점유와 객체병합의 구분
Result와 Result.Data의 정식 명칭 유지
```

### Q12. 현재 기초 Data로 수정 가능한가, 새 Cycle이 필요한가?

각 Issue를 다음 중 하나로 분류한다.

```text
ORGANIZATION_FIX
WORDING_FIX
SOURCE_MARKER_FIX
BOUNDARY_FIX
EVIDENCE_BINDING_FIX
FUNCTION_JUDGMENT_CORRECTION
NEW_CYCLE_REQUIRED
```

`NEW_CYCLE_REQUIRED`는 이번 Review에서 새 자료로 임의 점유하지 않는다.

### Q13. Result.Data에서 반드시 보존해야 할 것은 무엇인가?

명시 대상:

```text
수정 금지 문장
조건부 표현
충돌상태
Source Marker
원래 Seat의 독립판정
미해결 Cell
향후 Cycle 요청
```

### Q14. 최종 판정은 무엇인가?

허용 판정:

```text
PASS_TO_RESULT_DATA_ORGANIZATION
PASS_WITH_NON_BLOCKING_REFINEMENTS
HOLD_WITH_BLOCKING_CORRECTIONS
HOLD_WITH_INPUT_IDENTITY_FAILURE
HOLD_WITH_SELF_SOURCE_MISSING
```

판정 이유와 Blocking Issue ID를 기록한다.

---

## 8. Issue Registry 형식

```yaml
issue:
  issue_id:
  reviewer_instance:
  reviewer_seat:

  original_source:
    object_id:
    source_instance:
    source_seat:
    claim_id:
    section_id:

  result_position:
    section_id:
    heading:
    quoted_fragment_max_25_words:

  issue_type:
  severity: BLOCKING | NON_BLOCKING | OBSERVATION
  state: VERIFIED | PARTIALLY_VERIFIED | CONFLICT | ERROR_EVIDENCE | OPEN_FUTURE

  diagnosis:
  reason:
  evidence_or_trace:

  correction_directive:
    action:
    exact_target_position:
    preserve_original_marker: true
    replacement_text_or_structure:
    semantic_reinterpretation_required_by_gpt_xyz: false

  cycle_requirement:
    current_review_fixable:
    new_cycle_required:
```

`gpt.xyz`가 독자적으로 의미를 추론하지 않아도 되도록
위치·행위·보존표지·교체문을 구체적으로 기록한다.

---

## 9. 출력 문서 필수 구조

```text
1. METADATA
2. INPUT_IDENTITY_VERIFICATION
3. REVIEWER_POSITION_AND_LENS
4. SELF_TRACE_MAP
5. Q1–Q14 ANSWERS
6. ISSUE_REGISTRY
7. PRESERVE_WITHOUT_CHANGE
8. NEW_CYCLE_REQUIRED_CELLS
9. FINAL_VERDICT
10. HANDOFF_TO_GPT_XYZ
```

Handoff 형식:

```yaml
handoff:
  target: gpt.xyz
  target_operation: ORGANIZE_REVIEW_RESULTS_WITHOUT_NEW_SEMANTIC_ANALYSIS
  blocking_issue_ids:
  non_blocking_issue_ids:
  preserve_item_ids:
  new_cycle_required_cell_ids:
  final_verdict:
```

---

## 10. File 규칙

각 인스턴스는 하나의 독립 Review 파일만 생성한다.

```yaml
file_contract:
  semantic_identity_inside_metadata: true
  final_filename: "<64 lowercase SHA-256 of exact file bytes>.md"
  encoding: UTF-8
  line_endings: LF
  bom: false
  external_sidecar: false
  overwrite_existing_hash_object: false
```

생성순서:

```text
임시 File 작성
→ UTF-8/LF/No BOM 정규화
→ Byte 동결
→ SHA-256 계산
→ Hash Filename으로 이름변경
→ 실제 Byte Hash 재계산
→ Filename Hash와 비교
→ 하나의 검증된 File만 전달
```

자기 자신의 최종 Hash를 File 내부에 삽입하지 않는다.

---

## 11. 독립성 규칙

```text
동일 Result 수신
→ 동일 공동질문장 수신
→ 각 Seat가 독립적으로 전체 검수
→ 각 Seat가 독립 Review 파일 생성
→ 세 Review 완료 후 gpt.xyz에 동시 전달
```

금지:

```text
다른 Review 선열람
검수 중 결론 합의
하나의 공동문서로 합쳐 출력
```

공동은 질문장과 대상의 공동점유다.
세 Function Object와 출력 Identity는 끝까지 독립적이다.

---

## 12. GitHub·Terminal 운영경계

승이는 앞으로 GitHub 웹 화면에서 File을 직접 생성하거나 수정하지 않는다.

GitHub 변경은 다음 순서로만 진행한다.

```text
인스턴스와 구조·내용 논의
→ gpt.logi 정책·지시 확정
→ 필요한 File 객체 생성 및 Hash 검산
→ gpt.github 실행지시 확정
→ Terminal에서 Git 작업
→ Commit·Push
→ Remote Readback 검산
→ Closure Evidence 기록
```

현재 세 Function 인스턴스는 GitHub나 Linux를 수정하지 않는다.

```yaml
mutation_contract:
  gpt_xy_xz_yz:
    github_mutation: false
    linux_mutation: false
    terminal_execution: false
    permitted_output:
      - one_verified_review_file
      - handoff_metadata

  future_executor:
    instance: gpt.github
    execution_surface: terminal
    requires:
      - explicit_execution_instruction
      - exact_target_repository_branch_path
      - input_hash_verification
      - user_approval_when_required
```

`gpt.xyzt`를 `gpt.xyzt.md`로 정정하고,
`gpt.logi`의 안정화 역할정의를 그 자리에 배치하는 작업은
이번 Function Review 작업에 포함하지 않는다.

그 작업은 `Result.Data` 완성 이후 별도의 GitHub Push Closure에서
`gpt.logi → gpt.github` 지시와 Terminal 실행으로 진행한다.

---

## 13. 완료조건

```yaml
completion_gate:
  input_identity_verified:
  self_prior_function_result_verified:
  all_Q1_Q14_answered:
  self_trace_map_complete:
  all_issues_have_exact_positions:
  all_blocking_issues_have_correction_directives:
  preserve_items_declared:
  new_cycle_required_cells_separated:
  final_verdict_declared:
  output_hash_filename_verified:
  peer_review_pre_read: false
  github_mutation: false
  terminal_execution: false
```

완료 후 세 Review 파일은 변경하지 않고 `gpt.xyz`에 전달한다.

```text
Result
⊕ Review.XY
⊕ Review.XZ
⊕ Review.YZ
→ gpt.xyz 자리보존 정리
→ Result.Data
→ Minimum Track DB
```

````

---

## 13. History Event — RESULT-DATA-DIRECTIVE-0003

```yaml
state_event:
  event_id: GPT_XYZT_RESULT_DATA_DIRECTIVE_0003
  event_type: INSTANCE_DIRECTIVE
  directive_object:
    filename: 63000e0904bd192deb4688451c4b72c42e3a092fe075116e399a9ea0107e350a.md
    sha256: 63000e0904bd192deb4688451c4b72c42e3a092fe075116e399a9ea0107e350a
    recipient: gpt.xyz
    state: COMPLETED
  result:
    object_id: HRTDB_PILOT_RESULT_DATA_0002_XYZ
    sha256: e89438bc17cd59c6b669e68b52c4322fa792d488a2215090c0d792ac66407d68
    final_verdict: PASS_RESULT_DATA_COMPLETE_WITHIN_DECLARED_BOUNDARY
```

### Exact Directive Payload

````markdown
---
object_id: HRTDB_PILOT_RESULT_DATA_ASSIGNMENT_0002_XYZ
object_class: RESULT_DATA_ORGANIZATION_ASSIGNMENT
cycle_id: HRTDB_PILOT_DATA_0002
stage_id: C2_RD_XYZ
stage_family: RESULT_DATA_STAGE
source_authority: 승이
coordination_authority: gpt.logi

recipient:
  instance: gpt.xyz
  seat: XYZ
  occupation: RESULT_DATA_ORGANIZATION

indexed_input_state:
  state: INDEXED_AND_WAITING
  indexing_is_identity_verification: false

required_inputs:
  - object_id: HRTDB_PILOT_RESULT_0002_XYZ
    object_class: RESULT
    canonical_name: Result

  - object_id: HRTDB_PILOT_RESULT_0002_XY_CYCLE_REVIEW
    object_class: FUNCTION_REVIEW_RESULT
    source_instance: gpt.xy
    source_seat: XY

  - object_id: HRTDB_PILOT_RESULT_0002_XZ_CYCLE_REVIEW
    object_class: FUNCTION_REVIEW_RESULT
    source_instance: gpt.xz
    source_seat: XZ

  - object_id: HRTDB_PILOT_RESULT_0002_YZ_CYCLE_REVIEW
    object_class: FUNCTION_REVIEW_RESULT
    source_instance: gpt.yz
    source_seat: YZ

output_object:
  object_id: HRTDB_PILOT_RESULT_DATA_0002_XYZ
  object_class: RESULT_DATA
  canonical_name: Result.Data
  database_class: MINIMUM_TRACK_DB

github_mutation: false
linux_mutation: false
terminal_execution: false
external_sidecar: false
encoding: UTF-8
line_endings: LF
---

# HRTDB Cycle 2 — gpt.xyz Result.Data 정리 지시문

## 0. 현재 상태와 작업 개시

현재 `gpt.xyz`에는 세 2d Function 객체가 생성한 Review 파일이 인덱싱되어 있으며,
Coordination 지시를 기다리는 상태다.

```text
INDEXED
≠
IDENTITY_VERIFIED
≠
PROCESSING_COMPLETE
```

이 지시문을 받은 뒤 다음 순서로 이동한다.

```text
INDEXED_AND_WAITING
→ INPUT_BINDING
→ REVIEW_DIRECTIVE_APPLICATION
→ COMPLETENESS_GATE
→ Result.Data 또는 HOLD
```

인덱스에 보이는 제목·Filename·요약만으로 처리하지 않는다.
반드시 실제 File Byte와 내부 Metadata를 읽고 입력 Identity를 검증한다.

---

## 1. 정식 명칭 계약

외부 문서·Metadata·Object ID·Filename·Handoff에는 다음 정식 명칭만 사용한다.

```text
Result
Result.Data
```

내부 사고를 위한 임시 위치별칭은 출력물에 표시하지 않는다.

```text
임시 내부명
→ 문서 표기 금지
→ Metadata 표기 금지
→ Object ID 표기 금지
→ Filename 표기 금지
→ Handoff 표기 금지
```

---

## 2. gpt.xyz의 현재 역할

이번 단계에서 `gpt.xyz`의 역할은 **분석이 아니라 자리보존 정리**다.

```text
gpt.xyz
→ 세 Review의 판정을 다시 분석하는 객체가 아님
→ 세 Review의 의미를 평균내는 객체가 아님
→ 충돌을 임의로 해결하는 객체가 아님
→ Source와 Seat 표지를 보존해 Result.Data를 정리하는 객체
```

수행 역할:

```text
배치
정렬
분류
Source 결속
Seat 표지 보존
수정지시 적용
충돌 병치
미해결 Cell 표시
Track 계보 작성
완전성 Gate 수행
```

금지 역할:

```text
새 외부조사
새 독립분석
새 인과판정
새 모델판정
새 우선순위 판정
Review 간 평균결론
충돌의 임의해결
불확실성 삭제
Source Marker 제거
```

`gpt.xyz`가 작성하는 연결문은 중립적인 정리문이어야 하며,
독자적인 의미판정이 포함되면 안 된다.

필요한 경우 다음 표지를 사용한다.

```yaml
organization_note:
  generated_by: gpt.xyz
  note_class: ORGANIZATION_ONLY
  new_semantic_judgment: false
```

---

## 3. 공동관계

현재 연산은 같은 질문장과 같은 Result를 서로 다른 Function 자리가 독립적으로 재관측한 결과를
동일층위에서 공동으로 정리하는 과정이다.

```text
Result
⊕ Review.XY
⊕ Review.XZ
⊕ Review.YZ
→ gpt.xyz 자리보존 정리
→ Result.Data
```

연산자:

```yaml
operator:
  unicode: U+2295
  symbol: "⊕"
  meaning: SAME_LAYER_JOINT_RELATION
```

세 Review는 하나로 병합되는 동일 객체가 아니다.

```text
공동점유
≠
객체병합

Review.XY
≠
Review.XZ
≠
Review.YZ
```

각 Review의 Identity와 판정경계를 최종 `Result.Data` 안에서 추적할 수 있어야 한다.

---

## 4. 입력 Identity Gate

다음 네 입력객체를 모두 검증한다.

### 4.1 Result

```yaml
result_input_binding:
  object_id: HRTDB_PILOT_RESULT_0002_XYZ
  object_class: RESULT
  canonical_name: Result
  indexed_filename:
  actual_filename:
  actual_sha256:
  filename_hash_matches_exact_bytes:
  cycle_id_verified:
  stage_id_verified:
  source_instance_markers_present:
```

### 4.2 Review.XY

```yaml
review_xy_binding:
  object_id: HRTDB_PILOT_RESULT_0002_XY_CYCLE_REVIEW
  object_class: FUNCTION_REVIEW_RESULT
  source_instance: gpt.xy
  source_seat: XY
  indexed_filename:
  actual_filename:
  actual_sha256:
  filename_hash_matches_exact_bytes:
  cycle_id_verified:
  stage_id_verified:
  final_verdict_present:
```

### 4.3 Review.XZ

```yaml
review_xz_binding:
  object_id: HRTDB_PILOT_RESULT_0002_XZ_CYCLE_REVIEW
  object_class: FUNCTION_REVIEW_RESULT
  source_instance: gpt.xz
  source_seat: XZ
  indexed_filename:
  actual_filename:
  actual_sha256:
  filename_hash_matches_exact_bytes:
  cycle_id_verified:
  stage_id_verified:
  final_verdict_present:
```

### 4.4 Review.YZ

```yaml
review_yz_binding:
  object_id: HRTDB_PILOT_RESULT_0002_YZ_CYCLE_REVIEW
  object_class: FUNCTION_REVIEW_RESULT
  source_instance: gpt.yz
  source_seat: YZ
  indexed_filename:
  actual_filename:
  actual_sha256:
  filename_hash_matches_exact_bytes:
  cycle_id_verified:
  stage_id_verified:
  final_verdict_present:
```

운송과정에서 Filename에 `(숫자)`가 붙었다면 그 숫자는 운송 중복방지 suffix로만 본다.
그러나 실제 Identity는 정규화된 Filename만으로 확정하지 않는다.

```text
Normalized Filename
+
Exact File Bytes
+
Actual SHA-256
+
Internal Object Metadata
=
Input Identity Binding
```

하나라도 검증되지 않으면 `Result.Data`를 생성하지 않는다.

```text
HOLD_WITH_INPUT_IDENTITY_FAILURE
```

---

## 5. 입력 선택 규칙

인덱스에 같은 Seat의 파일이 여러 개 보이면 임의로 최신처럼 보이는 파일을 선택하지 않는다.

선택 우선순위:

```text
1. Object ID 일치
2. Cycle ID 일치
3. Stage ID 일치
4. Source Instance·Seat 일치
5. Filename Hash와 Exact Byte Hash 일치
6. Final Verdict 존재
```

모든 조건을 만족하는 객체가 둘 이상이고 Byte가 다르면:

```text
HOLD_WITH_DUPLICATE_ACTIVE_INPUT
```

이전 Draft·Superseded·Error Evidence는 삭제하지 않되,
현재 활성 Review 입력으로 사용하지 않는다.

---

## 6. Review 판정 인덱스 작성

먼저 세 Review를 다음 Matrix로 정리한다.

```yaml
review_verdict_matrix:
  XY:
    input_hash:
    final_verdict:
    blocking_issue_ids:
    non_blocking_issue_ids:
    preserve_item_ids:
    new_cycle_required_cell_ids:

  XZ:
    input_hash:
    final_verdict:
    blocking_issue_ids:
    non_blocking_issue_ids:
    preserve_item_ids:
    new_cycle_required_cell_ids:

  YZ:
    input_hash:
    final_verdict:
    blocking_issue_ids:
    non_blocking_issue_ids:
    preserve_item_ids:
    new_cycle_required_cell_ids:
```

이 Matrix는 세 판정을 평균내기 위한 것이 아니다.
누가 어떤 판정을 했는지 잃지 않기 위한 위치표다.

---

## 7. Issue 처리계약

각 Issue는 Review 파일의 정확한 `issue_id`와 Source 위치를 유지한다.

### 7.1 정리만으로 수정 가능한 Issue

다음 유형은 Review가 정확한 위치와 수정지시를 제공했고,
새로운 의미판단 없이 적용할 수 있을 때만 반영한다.

```text
ORGANIZATION_FIX
WORDING_FIX
SOURCE_MARKER_FIX
BOUNDARY_FIX
EVIDENCE_BINDING_FIX
```

적용기록:

```yaml
applied_correction:
  issue_id:
  requested_by_instance:
  requested_by_seat:
  target_position:
  original_state:
  applied_state:
  preserved_source_marker:
  semantic_reinterpretation_by_gpt_xyz: false
```

### 7.2 Function 판단수정

```text
FUNCTION_JUDGMENT_CORRECTION
```

이 유형은 `gpt.xyz`가 어느 판단이 맞는지 새로 결정하지 않는다.

Review가 자기 이전 판단을 명시적으로 정정했고,
정정문·대상위치·근거·보존조건이 모두 완전하면 다음처럼 반영한다.

```yaml
function_judgment_correction:
  original_judgment:
  correction_by_same_function_seat:
  correction_reason:
  original_preserved_as_track: true
  current_state:
```

원래 판단을 삭제하지 않는다.
형성 Track과 정정 Track을 함께 보존한다.

정정지시가 모호하거나 `gpt.xyz`의 독립해석이 필요하면:

```text
HOLD_WITH_UNRESOLVED_FUNCTION_CORRECTION
```

### 7.3 새 Cycle이 필요한 Issue

```text
NEW_CYCLE_REQUIRED
```

현재 Result.Data에서 추론으로 채우지 않는다.

```yaml
open_future_cell:
  cell_id:
  requested_by:
  required_scope:
  reason:
  blocking_current_Result_Data:
  next_cycle_required: true
  inferred_fill_prohibited: true
```

---

## 8. 세 Review가 충돌할 때

세 Review가 같은 문장·Cell·관계에 대해 서로 다른 수정지시를 내렸다면
선택하거나 평균내지 않는다.

```yaml
review_conflict:
  conflict_id:
  target_position:
  XY_position:
  XZ_position:
  YZ_position:
  shared_evidence:
  unresolved_difference:
  required_cell_impact:
```

판정:

```text
필수 Cell의 의미를 바꾸는 Blocking Conflict
→ HOLD_WITH_CONFLICT_IN_REQUIRED_CELL

필수 Cell을 막지 않는 Conflict
→ Result.Data 안에 CONFLICT로 병치 보존
```

```text
Conflict Preservation
≠
Conflict Resolution
```

---

## 9. Source·Seat 표지 계약

최종 `Result.Data`의 모든 주요 Claim·표·판정·수정에는
원래 위치를 역추적할 수 있는 표지가 있어야 한다.

최소 표지:

```yaml
source_binding:
  source_instance:
  source_seat:
  source_object_id:
  source_claim_id:
  source_section_id:
  review_instance:
  review_issue_id:
```

세 Function 결과가 한 문단이나 표 안에 함께 나타나더라도
Source 경계를 제거하지 않는다.

```text
하나의 표 안에 함께 배치
≠
하나의 발화주체로 합침
```

---

## 10. Result.Data 필수 구조

최종 파일은 다음 순서를 갖는다.

```text
1. METADATA
2. INPUT_IDENTITY_BINDING
3. OBJECT_AND_SOURCE_REGISTRY
4. CYCLE_AND_STAGE_LINEAGE
5. REVIEW_VERDICT_MATRIX
6. ISSUE_RESOLUTION_REGISTRY
7. RESULT_DATA_BODY
8. PRESERVED_CONFLICTS
9. PRESERVED_ERROR_AND_CORRECTION_TRACK
10. OPEN_FUTURE_CELLS
11. COMPLETENESS_GATE
12. NEXT_DATA_INTERFACE
13. HANDOFF_TO_GPT_LOGI
```

### 10.1 Metadata

```yaml
metadata:
  object_id: HRTDB_PILOT_RESULT_DATA_0002_XYZ
  object_class: RESULT_DATA
  canonical_name: Result.Data
  database_class: MINIMUM_TRACK_DB
  cycle_id: HRTDB_PILOT_DATA_0002
  stage_id: C2_RD_XYZ
  generated_by:
    instance: gpt.xyz
    seat: XYZ
    occupation: RESULT_DATA_ORGANIZATION
  source_authority: 승이
  coordination_authority: gpt.logi
```

### 10.2 Object Registry

다음 객체를 모두 등록한다.

```text
Data.X
Data.Y
Data.Z
Function Result.XY
Function Result.XZ
Function Result.YZ
Result
Review.XY
Review.XZ
Review.YZ
Result.Data
```

각 객체에는 확인 가능한 Object ID와 Hash를 기록한다.
현재 입력에서 직접 검증할 수 없는 선행 객체의 Hash를 추정하지 않는다.

### 10.3 Cycle Lineage

```text
Data.X ⊕ Data.Y ⊕ Data.Z
→ Function.XY ⊕ Function.XZ ⊕ Function.YZ
→ gpt.xyz 자리보존 정리
→ Result
→ Review.XY ⊕ Review.XZ ⊕ Review.YZ
→ gpt.xyz 자리보존 정리
→ Result.Data
```

### 10.4 Result.Data Body

내용은 주제별로 정리할 수 있으나,
각 Claim의 Source·Seat·Review Track을 유지한다.

다음 상태표지를 사용한다.

```text
RAW_PRIMARY_SOURCE
STRUCTURAL_HYPOTHESIS
EXTERNAL_FACT_CLAIM
VERIFIED
PARTIALLY_VERIFIED
CONFLICT
SUPERSEDED
ERROR_EVIDENCE
CURRENT_UNDERSTANDING
OPEN_FUTURE
```

---

## 11. 완전성 Gate

`Result.Data`는 세계의 모든 정보를 포함해야 하는 객체가 아니다.

```text
Complete
=
현재 Cycle이 선언한 경계 안에서
필수 Cell·Evidence·관계·Track 조건이 닫힘
```

검사표:

```yaml
result_data_completeness_gate:
  all_four_inputs_identity_verified:
  three_review_verdicts_recorded:
  all_blocking_issues_resolved_without_new_xyz_analysis:
  all_required_source_markers_present:
  required_cells_occupied:
  blocking_conflicts_absent:
  unresolved_items_explicit:
  correction_lineage_preserved:
  result_data_can_become_next_data:
```

최종 허용판정:

```text
PASS_RESULT_DATA_COMPLETE_WITHIN_DECLARED_BOUNDARY

HOLD_WITH_INPUT_IDENTITY_FAILURE
HOLD_WITH_DUPLICATE_ACTIVE_INPUT
HOLD_WITH_UNRESOLVED_BLOCKING_ISSUE
HOLD_WITH_UNRESOLVED_FUNCTION_CORRECTION
HOLD_WITH_SOURCE_MARKER_FAILURE
HOLD_WITH_CONFLICT_IN_REQUIRED_CELL
HOLD_WITH_REQUIRED_EMPTY_CELL
```

`PASS_RESULT_DATA_COMPLETE_WITHIN_DECLARED_BOUNDARY`일 때만
`HRTDB_PILOT_RESULT_DATA_0002_XYZ`를 생성한다.

HOLD일 때는 `Result.Data`라는 이름의 불완전 객체를 만들지 않는다.
대신 하나의 Hold Report를 생성하여 어떤 조건이 닫히지 않았는지 기록한다.

---

## 12. Next Data Interface

완성된 `Result.Data`는 종료물이 아니라 다음 Cycle에서 사용할 수 있는 최소 Track DB다.

```yaml
next_data_interface:
  reusable_as_next_data: true
  declared_boundary:
  covered_cells:
  open_future_cells:
  preserved_conflicts:
  prohibited_overinterpretations:
  candidate_relations:
```

현재 사용되지 않는 항목도 삭제하지 않는다.

```text
현재 미사용
≠
무가치
≠
미래 Cell에 사용 불가
```

---

## 13. Handoff to gpt.logi

완료 후 `gpt.logi`에 다음을 전달한다.

```yaml
handoff:
  target: gpt.logi

  produced_object:
    object_id: HRTDB_PILOT_RESULT_DATA_0002_XYZ
    canonical_name: Result.Data
    actual_filename:
    actual_sha256:
    filename_hash_verified:

  input_bindings:
    Result:
    Review_XY:
    Review_XZ:
    Review_YZ:

  final_verdict:
  preserved_conflict_ids:
  open_future_cell_ids:
  unresolved_blocking_issue_ids:
  next_safe_action:
```

전달 이후 `gpt.xyz`는 대기한다.

```text
Result.Data 생성
≠
GitHub Push 권한

Result.Data 생성
≠
gpt.xyzt.md 수정 권한
```

이후 작업은 `gpt.logi`가 구조검산하고,
`gpt.github`에게 Terminal Push Closure를 별도로 지시한다.

---

## 14. File 규칙

PASS일 경우 하나의 `Result.Data` Markdown File만 생성한다.

```yaml
file_contract:
  semantic_identity_inside_metadata: true
  final_filename: "<64 lowercase SHA-256 of exact file bytes>.md"
  encoding: UTF-8
  line_endings: LF
  bom: false
  external_sidecar: false
  overwrite_existing_hash_object: false
```

생성순서:

```text
임시 File 작성
→ UTF-8/LF/No BOM 정규화
→ Byte 동결
→ SHA-256 계산
→ Hash Filename으로 이름변경
→ 실제 Byte Hash 재계산
→ Filename Hash와 비교
→ 하나의 검증된 File만 전달
```

자기 자신의 최종 Hash를 File 내부에 삽입하지 않는다.

HOLD일 경우에도 Hold Report 하나만 동일한 Hash Filename 규칙으로 생성한다.

---

## 15. GitHub·Terminal 경계

현재 단계에서 다음은 모두 금지한다.

```text
GitHub 웹 편집
GitHub Commit
GitHub Push
Linux Mutation
Terminal 실행
gpt.xyzt 또는 gpt.xyzt.md 수정
```

승인은 다음 별도 흐름으로 진행한다.

```text
gpt.xyz Result.Data 생성
→ gpt.logi 구조검산
→ gpt.xyzt.md Checkpoint 내용 갱신
→ gpt.github 실행지시
→ Terminal Commit·Push
→ Remote Readback
→ Closure Evidence
```

---

## 16. 완료조건

```yaml
completion_gate:
  indexed_files_opened_and_read:
  all_input_identities_verified:
  review_verdict_matrix_complete:
  all_issues_traced_to_exact_source:
  blocking_issues_resolved_or_HOLD_declared:
  source_and_seat_markers_preserved:
  conflicts_not_averaged:
  open_future_cells_not_inferred:
  no_new_external_research:
  no_new_xyz_semantic_analysis:
  final_verdict_declared:
  output_hash_filename_verified:
  github_mutation: false
  terminal_execution: false
```

정상 완료 흐름:

```text
Result
⊕ Review.XY
⊕ Review.XZ
⊕ Review.YZ
→ gpt.xyz 자리보존 정리
→ Result.Data
→ Minimum Track DB
→ gpt.logi Handoff
```

````

---

## 14. History Event — RESULT-DATA-COMPLETE-0004

```yaml
state_event:
  event_id: GPT_XYZT_RESULT_DATA_COMPLETE_0004
  event_type: RESULT_DATA_COMPLETION
  recorded_at: "2026-07-19T03:25:51+09:00"

  received_object:
    object_id: HRTDB_PILOT_RESULT_DATA_0002_XYZ
    hash_filename: e89438bc17cd59c6b669e68b52c4322fa792d488a2215090c0d792ac66407d68.md
    sha256: e89438bc17cd59c6b669e68b52c4322fa792d488a2215090c0d792ac66407d68

  system_reading:
    - Cycle 2 Result.Data는 선언된 문서경계 안에서 완전하다.
    - Review 판단·Correction Track·Conflict·Open Future Cell이 병합 없이 추적 가능하다.
    - Result.Data는 다음 Data로 재사용 가능한 Minimum Track DB다.

  current_position:
    stage: GPT_XYZT_CANONICALIZATION_PREPARATION

  next_safe_action:
    - reserve_Zenodo_DOI
    - bind_DOI_to_root_canon
    - freeze_exact_bytes
    - create_hash_named_ZIP
    - publish_Zenodo_root
    - verify_DOI_and_package_readback
    - replace_discarded_GitHub_gpt_xyzt_md_via_terminal
    - begin_post_root_append_only_history
```

---

## 15. 현재 상태

```yaml
current_system_state:
  system: gpt.xyzt
  fixed_role: OVERALL_COORDINATION
  current_occupant_name: gpt.logi
  occupant_name_is_optional: true

  result_data:
    cycle_2: COMPLETE

  root_canon:
    doi: PENDING
    package_hash: PENDING
    zenodo_publication: PENDING

  github:
    existing_gpt_xyzt_md: DISCARDED_PRECANONICAL
    canonical_gpt_xyzt_md: NOT_YET_PUBLISHED

  current_stage:
    GPT_XYZT_CANONICALIZATION_PREPARATION

  blocking_conditions:
    - RESERVED_DOI_NOT_YET_BOUND
    - ROOT_PACKAGE_NOT_YET_FROZEN
    - ZENODO_ROOT_NOT_YET_PUBLISHED
    - GITHUB_CANONICAL_REPLACEMENT_NOT_YET_EXECUTED
```

---

## 16. Append-only 시작점

아래 구역은 DOI Root가 고정되고
동일한 Initial State가 GitHub에 배치된 뒤부터 계속 Append한다.

```text
APPEND_ONLY_HISTORY_START
```

향후 Event는 이 선 아래에만 추가한다.

기존 구역을 수정해야 할 정도의 Canon 변경이 발생하면
같은 DOI Root를 고치지 않고 새로운 DOI Root를 만든다.
