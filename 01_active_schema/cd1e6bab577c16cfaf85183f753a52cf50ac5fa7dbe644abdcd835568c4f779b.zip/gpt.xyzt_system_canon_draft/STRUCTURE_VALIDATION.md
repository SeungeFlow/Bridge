---
report_id: GPT_XYZT_SYSTEM_CANON_DRAFT_VALIDATION
target: gpt.xyzt.md
target_sha256: 72c96eeb5c03c6c1c5f3d53175cddbf5ae298706abadadeb60270e5b58309f4c
target_bytes: 46771
verdict: PASS_AS_DOI_BINDING_DRAFT
publication_gate: HOLD_FOR_RESERVED_DOI_AND_FINAL_FREEZE
---

# gpt.xyzt System Canon Draft — Structure Validation

## Verdict

```text
PASS_AS_DOI_BINDING_DRAFT
```

```text
HOLD_FOR_RESERVED_DOI_AND_FINAL_FREEZE
```

## Checks

- PASS — UTF8_LF_NO_BOM
- PASS — SYSTEM_DEFINED
- PASS — NAME_NOT_FIXED
- PASS — DOI_PLACEHOLDER_PRESENT
- PASS — DOI_NOT_MISLABELED_AS_CRYPTO_HASH
- PASS — APPEND_ONLY_DEFINED
- PASS — RESULT_DATA_BOUND
- PASS — RESULT_DATA_PASS
- PASS — EXACT_DIRECTIVE_2D_INCLUDED
- PASS — EXACT_DIRECTIVE_XYZ_INCLUDED
- PASS — OLD_REMOTE_DISCARDED

## Current Result.Data

```text
object_id: HRTDB_PILOT_RESULT_DATA_0002_XYZ
sha256: e89438bc17cd59c6b669e68b52c4322fa792d488a2215090c0d792ac66407d68
bytes: 52433
verdict: PASS_RESULT_DATA_COMPLETE_WITHIN_DECLARED_BOUNDARY
```

## DOI finalization requirement

This draft contains the placeholder:

```text
PENDING_RESERVED_DOI
```

Before publication:

1. Reserve a DOI in the Zenodo draft.
2. Replace the placeholder with the reserved DOI.
3. Freeze exact bytes.
4. Recompute all SHA-256 values.
5. Rebuild the hash-named ZIP.
6. Publish and perform DOI/package readback.
7. Use the DOI-bound exact initial file for the first canonical GitHub state.

The current ZIP is a review package, not the final Zenodo root package.
